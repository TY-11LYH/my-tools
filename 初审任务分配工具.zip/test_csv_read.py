#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试CSV读取功能
"""

import sys
import os
import csv
from datetime import datetime, timedelta

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')


def read_reviewers_from_csv(csv_dir, csv_dates):
    """
    从音频导入任务的CSV文件中提取主播名和uid
    """
    reviewers = set()

    for date_folder in csv_dates:
        folder_path = os.path.join(csv_dir, date_folder)
        if not os.path.exists(folder_path):
            print(f"  警告: 文件夹不存在 - {folder_path}")
            continue

        # 查找文件夹里的csv文件
        csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
        if not csv_files:
            print(f"  警告: 文件夹里没有CSV文件 - {folder_path}")
            continue

        csv_file = os.path.join(folder_path, csv_files[0])
        print(f"  读取文件: {csv_file}")

        # 尝试多种编码
        for encoding in ['utf-8', 'gbk', 'gb18030', 'utf-8-sig']:
            try:
                with open(csv_file, 'r', encoding=encoding) as f:
                    reader = csv.reader(f)
                    next(reader)  # 跳过表头
                    count = 0
                    for row in reader:
                        if len(row) > 3:
                            name = row[2].strip()
                            uid = row[3].strip()
                            if name and uid:
                                reviewers.add((name, uid))
                                count += 1
                print(f"    成功读取 (编码: {encoding})，提取 {count} 条记录")
                break  # 成功读取后跳出编码尝试循环
            except UnicodeDecodeError:
                continue  # 尝试下一种编码
            except Exception as e:
                print(f"    警告: 读取失败 - {e}")
                break

    return sorted(list(reviewers))


def get_next_tuesday():
    """计算下周二的日期"""
    today = datetime.now()
    days_until_tuesday = (1 - today.weekday() + 7) % 7
    if days_until_tuesday == 0:
        days_until_tuesday = 7
    next_tuesday = today + timedelta(days=days_until_tuesday)
    return next_tuesday


def main():
    print("===== CSV读取功能测试 =====\n")

    csv_dir = r'C:\Users\xbjt\Desktop\音频导入任务'
    csv_dates = ['4.29上传', '4.30上传']

    print(f"CSV目录: {csv_dir}")
    print(f"日期文件夹: {', '.join(csv_dates)}\n")

    # 提取主播信息
    print("开始读取CSV文件...")
    reviewers = read_reviewers_from_csv(csv_dir, csv_dates)

    print(f"\n===== 提取结果 =====")
    print(f"共提取 {len(reviewers)} 位主播（已去重）\n")

    if reviewers:
        print("主播列表：")
        for i, (name, uid) in enumerate(reviewers, 1):
            print(f"  {i}. {name} (UID: {uid})")

        # 计算下周二
        next_tuesday = get_next_tuesday()
        print(f"\n终审批量开通截止时间: {next_tuesday.strftime('%Y-%m-%d')} (下周二)")
        print(f"文件名将生成: {next_tuesday.strftime('%m.%d').lstrip('0')}终审批量开通.xlsx")
    else:
        print("警告: 没有提取到任何主播信息")


if __name__ == '__main__':
    main()
