#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
初审任务分配脚本

使用方法:
  python distribute.py --input 本周.xlsx --leave 泠月 墨岚欣
  python distribute.py --input 本周.xlsx --leave 泠月 --leave-last-week 正能量范儿 妙言
  python distribute.py --input 本周.xlsx --csv-dates 4.29上传 4.30上传

工作流程:
  1. 复制模板xlsx，在新文件中填好总表「初审分配表」的前三列:
     A列=书名, B列=截止日期, C列=试音数
  2. 运行本脚本，指定请假人员
  3. 脚本自动分配任务、填写审听人、更新各初审员个人sheet
  4. 生成「xxx_已分配.xlsx」
  5. 如果提供了 --csv-dates，还会生成终审批量开通表格
"""

import argparse
import sys
import os
import csv
import re
from datetime import datetime, timedelta

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')

try:
    from openpyxl import load_workbook
except ImportError:
    print("需要安装 openpyxl: pip install openpyxl")
    sys.exit(1)

MAIN_SHEET = '初审分配表'
BONUS = 20


def get_reviewers(wb):
    sheets = wb.sheetnames
    return sheets[1:]


def read_books(ws):
    books = []
    row = 2
    while True:
        book_name = ws.cell(row=row, column=1).value
        if book_name is None or str(book_name).strip() == '':
            break
        deadline = ws.cell(row=row, column=2).value
        count = ws.cell(row=row, column=3).value
        if count is None:
            print(f"  警告: 第{row}行试音数为空，已跳过")
            row += 1
            continue
        books.append({
            'row': row,
            'book_name': str(book_name).strip(),
            'deadline': str(deadline).strip() if deadline else '',
            'count': int(count),
        })
        row += 1
    return books


def group_books(books):
    """
    按书名分组：去掉末尾数字后相同的行视为同一本书。
    返回: [(base_name, [book, ...], total_count), ...] 按总条数降序排列。
    """
    groups = {}
    for b in books:
        base = re.sub(r'\d+$', '', b['book_name'])
        if base not in groups:
            groups[base] = []
        groups[base].append(b)

    result = []
    for base, items in groups.items():
        total = sum(b['count'] for b in items)
        result.append((base, items, total))

    result.sort(key=lambda x: x[2], reverse=True)
    return result


def distribute_books(books, reviewers, leave_this_week, leave_last_week):
    """
    以整本书为单位，使用LPT贪心算法分配。
    同一本书的所有部分分给同一个人，不拆分。
    上周请假的初审员本周多分约20%。
    """
    available = [r for r in reviewers if r not in leave_this_week]

    if not available:
        print("错误: 没有可用的初审员！")
        sys.exit(1)

    total = sum(b['count'] for b in books)
    avg = total / len(available)

    boosted = [r for r in available if r in leave_last_week]
    num_boosted = len(boosted)
    num_normal = len(available) - num_boosted

    if num_boosted > 0 and num_normal > 0:
        boosted_target = avg * (1 + BONUS / 100)
        normal_target = (total - num_boosted * boosted_target) / num_normal
    else:
        boosted_target = avg
        normal_target = avg

    targets = {}
    for r in available:
        targets[r] = boosted_target if r in boosted else normal_target

    # 按书分组，按总条数降序
    book_groups = group_books(books)

    # LPT贪心：每本书分给当前工作量最少的人
    # 上周请假的人初始工作量为负数（先少分），相当于让其他人先达到平均值
    current_totals = {}
    for r in available:
        if r in boosted:
            current_totals[r] = -avg * (BONUS / 100)
        else:
            current_totals[r] = 0

    assignment = []
    reviewer_totals = {r: 0 for r in available}

    for base_name, items, group_total in book_groups:
        best_reviewer = min(available, key=lambda r: current_totals[r])
        for b in items:
            assignment.append((b, best_reviewer))
            reviewer_totals[best_reviewer] += b['count']
        current_totals[best_reviewer] += group_total

    return assignment, reviewer_totals, targets


def get_next_tuesday():
    """计算下周二的日期（下个周一+1天）"""
    today = datetime.now()
    days_until_next_monday = (7 - today.weekday()) % 7
    if days_until_next_monday == 0:
        days_until_next_monday = 7
    next_tuesday = today + timedelta(days=days_until_next_monday + 1)
    return next_tuesday.replace(hour=0, minute=0, second=0, microsecond=0)


def get_this_tuesday():
    """计算本周二的日期"""
    today = datetime.now()
    days_until_this_tuesday = (1 - today.weekday()) % 7
    if days_until_this_tuesday == 0 and today.weekday() != 1:
        days_until_this_tuesday = 7
    this_tuesday = today + timedelta(days=days_until_this_tuesday)
    return this_tuesday.replace(hour=0, minute=0, second=0, microsecond=0)


def read_reviewers_from_csv(csv_dir, csv_dates):
    """
    从音频导入任务的CSV文件中提取主播名和uid
    csv_dir: 音频导入任务文件夹路径
    csv_dates: 两个日期文件夹名列表，如 ['4.29上传', '4.30上传']
    返回: [(主播名, uid), ...] 去重后的列表
    """
    reviewers = set()

    for date_folder in csv_dates:
        folder_path = os.path.join(csv_dir, date_folder)
        if not os.path.exists(folder_path):
            print(f"  警告: 文件夹不存在 - {folder_path}")
            continue

        # 查找文件夹里的csv文件
        csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
        if not csv_files:
            print(f"  警告: 文件夹里没有CSV文件 - {folder_path}")
            continue

        csv_file = os.path.join(folder_path, csv_files[0])
        # 尝试多种编码
        for encoding in ['utf-8', 'gbk', 'gb18030', 'utf-8-sig']:
            try:
                with open(csv_file, 'r', encoding=encoding) as f:
                    reader = csv.reader(f)
                    next(reader)  # 跳过表头
                    for row in reader:
                        if len(row) > 3:
                            name = row[2].strip()
                            uid = row[3].strip()
                            if name and uid:
                                reviewers.add((name, uid))
                break  # 成功读取后跳出编码尝试循环
            except UnicodeDecodeError:
                continue  # 尝试下一种编码
            except Exception as e:
                print(f"  警告: 读取CSV文件失败 - {csv_file}: {e}")
                break

    return sorted(list(reviewers))


def generate_final_review_table(reviewers, next_tuesday, this_tuesday, template_path, output_dir):
    """
    生成终审批量开通表格
    reviewers: [(主播名, uid), ...]
    next_day: 后一天的日期
    template_path: 模板文件路径
    output_dir: ���出文件夹
    """
    # 读取模板
    wb = load_workbook(template_path)
    ws = wb.active

    # 清空模板数据（保留表头）
    for row in range(2, ws.max_row + 1):
        for col in range(1, ws.max_column + 1):
            ws.cell(row=row, column=col).value = None

    # 填写数据
    account_deadline = datetime(2026, 12, 31)
    role = "2交付版权方"

    for i, (name, uid) in enumerate(reviewers, 2):
        ws.cell(row=i, column=1).value = uid
        ws.cell(row=i, column=2).value = name
        ws.cell(row=i, column=4).value = account_deadline
        ws.cell(row=i, column=4).number_format = 'mm-dd-yy'
        ws.cell(row=i, column=5).value = role
        ws.cell(row=i, column=6).value = next_tuesday
        ws.cell(row=i, column=6).number_format = 'mm-dd-yy'

    # 生成输出文件名（使用本周二的日期）
    date_str = this_tuesday.strftime('%m.%d').lstrip('0')
    output_file = os.path.join(output_dir, f"{date_str}终审批量开通.xlsx")
    wb.save(output_file)

    return output_file


def main():
    parser = argparse.ArgumentParser(
        description='初审任务分配脚本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python distribute.py --input 本周.xlsx --leave 泠月 墨岚欣
  python distribute.py --input 本周.xlsx --leave 泠月 --leave-last-week 正能量范儿 妙言
  python distribute.py --input 本周.xlsx --output 第18周_已分配.xlsx
  python distribute.py --input 本周.xlsx --csv-dates 4.29上传 4.30上传
        """)
    parser.add_argument('--input', required=True, help='已填好前三列的xlsx文件')
    parser.add_argument('--leave', nargs='*', default=[], help='本周请假的初审员')
    parser.add_argument('--leave-last-week', nargs='*', default=[],
                        help='上周请假的初审员，本周会多分约20%')
    parser.add_argument('--output', default=None, help='输出文件路径')
    parser.add_argument('--csv-dates', nargs='*', default=[],
                        help='音频导入任务的日期文件夹名（两个），如：4.29上传 4.30上传')
    parser.add_argument('--csv-dir', default=r'C:\Users\xbjt\Desktop\音频导入任务',
                        help='音频导入任务文件夹路径')

    args = parser.parse_args()

    # 过滤空字符串
    args.leave = [n for n in args.leave if n.strip()]
    args.leave_last_week = [n for n in args.leave_last_week if n.strip()]

    if not os.path.exists(args.input):
        print(f"错误: 文件不存在 - {args.input}")
        sys.exit(1)

    print(f"读取文件: {args.input}")
    wb = load_workbook(args.input)

    reviewers = get_reviewers(wb)
    print(f"初审员: {', '.join(reviewers)}")

    for name in args.leave + args.leave_last_week:
        if name not in reviewers:
            print(f"  警告: '{name}' 不在初审员列表中，请检查拼写")

    main_ws = wb[MAIN_SHEET]
    books = read_books(main_ws)

    if not books:
        print("错误: 总表没有数据！请先填好书名、截止日期和试音数。")
        sys.exit(1)

    total = sum(b['count'] for b in books)
    print(f"\n本周共 {len(books)} 本书，{total} 条试音")

    # 打印书名分组信息
    book_groups = group_books(books)
    print(f"共 {len(book_groups)} 本不同的书（同书不拆分）")
    for base, items, t in book_groups:
        if len(items) > 1:
            print(f"  《{base}》 {len(items)}个部分, 共{t}条")

    print(f"本周请假: {', '.join(args.leave) if args.leave else '无'}")
    print(f"上周请假: {', '.join(args.leave_last_week) if args.leave_last_week else '无'}")

    assignment, reviewer_totals, targets = distribute_books(
        books, reviewers, args.leave, args.leave_last_week
    )

    # 打印分配结果
    print("\n===== 分配结果 =====")
    for r in reviewers:
        if r in args.leave:
            print(f"  {r}: 请假")
        else:
            t = reviewer_totals[r]
            target = targets[r]
            tag = " (+20%补偿)" if r in args.leave_last_week and r not in args.leave else ""
            print(f"  {r}: {t} 条 (目标{target:.0f}){tag}")

    # 打印详细书目
    print("\n===== 详细分配 =====")
    for r in reviewers:
        if r in args.leave:
            continue
        reviewer_books = [book for book, rev in assignment if rev == r]
        if reviewer_books:
            print(f"\n  {r} ({reviewer_totals[r]}条):")
            for b in reviewer_books:
                print(f"    {b['book_name']} - {b['count']}条")

    confirm = input("\n确认分配结果并保存？(y/n): ")
    if confirm.strip().lower() != 'y':
        print("已取消。")
        sys.exit(0)

    # ===== 写入总表 =====
    for row in range(2, main_ws.max_row + 1):
        main_ws.cell(row=row, column=4).value = None
        main_ws.cell(row=row, column=5).value = None
        main_ws.cell(row=row, column=6).value = None

    data_end = len(books) + 1
    for row in range(data_end + 1, main_ws.max_row + 1):
        for col in range(1, 7):
            main_ws.cell(row=row, column=col).value = None

    reviewer_rows = {}
    for book, reviewer in assignment:
        r = book['row']
        main_ws.cell(row=r, column=4).value = reviewer
        if reviewer not in reviewer_rows:
            reviewer_rows[reviewer] = []
        reviewer_rows[reviewer].append(r)

    for reviewer, rows in reviewer_rows.items():
        last_row = max(rows)
        main_ws.cell(row=last_row, column=5).value = reviewer_totals[reviewer]

    total_row = len(books) + 2
    main_ws.cell(row=total_row, column=3).value = total

    # ===== 更新各初审员个人sheet =====
    for reviewer in reviewers:
        ws = wb[reviewer]
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row, max_col=ws.max_column):
            for cell in row:
                cell.value = None

        reviewer_books = [book for book, rev in assignment if rev == reviewer]
        if not reviewer_books:
            continue

        for i, book in enumerate(reviewer_books, 1):
            ws.cell(row=i, column=1).value = book['deadline']
            ws.cell(row=i, column=2).value = book['book_name']
            ws.cell(row=i, column=6).value = book['count']

        ws.cell(row=len(reviewer_books), column=7).value = reviewer_totals[reviewer]

    output = args.output
    if output is None:
        base, ext = os.path.splitext(args.input)
        output = f"{base}_已分配{ext}"

    wb.save(output)
    print(f"\n已保存: {output}")

    # ===== 生成终审批量开通表格 =====
    if args.csv_dates:
        print("\n===== 生成终审批量开通表格 =====")

        # 过滤空字符串
        csv_dates = [d for d in args.csv_dates if d.strip()]

        if len(csv_dates) != 2:
            print(f"错误: --csv-dates 需要提供两个日期文件夹名")
            sys.exit(1)

        # 提取主播信息
        print(f"从CSV文件中提取主播信息...")
        reviewers_csv = read_reviewers_from_csv(args.csv_dir, csv_dates)

        if not reviewers_csv:
            print("错误: 没有从CSV文件中提取到主播信息")
            sys.exit(1)

        print(f"共提取 {len(reviewers_csv)} 位主播")

        # 计算下周二和本周二
        next_tuesday = get_next_tuesday()
        this_tuesday = get_this_tuesday()
        print(f"截止时间: {next_tuesday.strftime('%Y-%m-%d')} (下周二)")

        # 生成终审批量开通表格
        template_path = r'C:\Users\xbjt\Desktop\终审批量开通\终审批量开通模板（周二上班发给大美）.xlsx'
        output_dir = r'C:\Users\xbjt\Desktop\终审批量开通'

        if not os.path.exists(template_path):
            print(f"错误: 模板文件不存在 - {template_path}")
            sys.exit(1)

        final_output = generate_final_review_table(reviewers_csv, next_tuesday, this_tuesday, template_path, output_dir)
        print(f"终审批量开通表格已保存: {final_output}")


if __name__ == '__main__':
    main()
