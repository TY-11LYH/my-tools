/**
 * 音频后期招募自动化工具
 *
 * 功能：
 * 1. 读取腾讯文档导出的CSV → 自动转换为LMS批量导入Excel格式
 * 2. 自动映射字段、转换格式（后期条件→数字，书籍类型→对应列标记1）
 * 3. 自动计算报名时间（发布日期→报名开始/截止/试音截止）
 * 4. 生成核对清单（TXT文件）
 */

const XLSX = require('xlsx');
const iconv = require('iconv-lite');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// ==================== 配置 ====================

// 腾讯文档CSV字段名（精确匹配）→ 内部短名
const CSV_FIELD_MAP = {
  '主播名（必填）': '主播名',
  '喜播UID，（如非喜播学员，请留手机号）（必填）': 'UID',
  '作品名称（必填）': '作品名称',
  '作品作者（必填）': '作品作者',
  '本书需要后期数量（必填）': '招募数量',
  '薪资构成（必填）': '薪资构成',
  '时薪酬劳（必填）': '时薪酬劳',
  '占整书分成比例/人（单位%）（必填）': '分成比例',
  '打包薪资/人（单位：元）（���填）': '打包薪资',
  '作品总字数（必填）': '作品总字数',
  '需求后期条件（选项已按照精度进行排列）（必填）': '后期条件',
  '每天交音集数/人（必填）': '每天交音',
  '每集预估时长（单位：分钟）（必填）': '每集预估',
  '作品总集数（必填）': '作品总集数',
  '书籍类别（必填）': '书籍类别',
  '后期制作具体要求+作品简介（必填）': '制作要求',
  '微信所用手机号（便于通知您终审）（必填）': '手机号',
  '提交者（自动）': '提交者',
  '提交时间（自动）': '提交时间',
  '状态': '状态',
};

// 将CSV原始字段名转为短名
function getField(row, shortName) {
  // 先找精确映射
  for (const [csvName, short] of Object.entries(CSV_FIELD_MAP)) {
    if (short === shortName && row[csvName] !== undefined) {
      return row[csvName];
    }
  }
  // 再找模糊匹配
  for (const key of Object.keys(row)) {
    if (key.includes(shortName)) return row[key];
  }
  return '';
}

// 后期条件：文字 → 数字
const POST_CONDITION_MAP = {
  '不限': 0, '干音': 1, '简配': 2, '中配': 3,
  '精配': 4, '超简配': 5, '简中配': 6, '中精配': 7,
};

// 书籍类型：腾讯文档关键词 → Excel列名
const BOOK_TYPE_MAP = {
  '言情': '浪漫言情', '浪漫言情': '浪漫言情', '���言': '古言宫斗',
  '古言宫斗': '古言宫斗', '宫斗': '古言宫斗', '玄幻': '玄幻奇幻',
  '玄幻奇幻': '玄幻奇幻', '奇幻': '玄幻奇幻', '穿越': '穿越架空',
  '穿越架空': '穿越架空', '架空': '穿越架空', '武侠': '武侠仙侠',
  '武侠仙侠': '武侠仙侠', '仙侠': '武侠仙侠', '都市': '都市生活',
  '都市生活': '都市生活', '历史': '历史军事', '历史军事': '历史军事',
  '军事': '历史军事', '人文': '人文社科', '人文社科': '人文社科',
  '社科': '人文社科', '恐怖': '恐怖悬疑', '恐怖悬疑': '恐怖悬疑',
  '悬疑': '恐怖悬疑', '灵异': '恐怖悬疑', '儿童': '少儿童书',
  '少儿童书': '少儿童书', '童书': '少儿童书',
};

// 所有书籍类型列名
const BOOK_TYPE_COLUMNS = [
  '浪漫言情', '古言宫斗', '玄幻奇幻', '穿越架空', '武侠仙侠',
  '都市生活', '历史军事', '人文社科', '恐怖悬疑', '少儿童书'
];

// Excel模板完整列名（41列，按顺序）
const EXCEL_COLUMNS = [
  '任务编号', '任务类型', '专辑归属', '就业方', '薪资类型', '基础薪资类型',
  '基础薪资', '提成薪资', '书名', '作者', '后期条件', '每天集数', '每集分钟数',
  '要求上架时间', '字数估算', ...BOOK_TYPE_COLUMNS,
  '书籍简介', '采样率48KHZ/44.1KHZ', '深度32bit', '码率192kbps/256kbps',
  '双声道', 'mp3', 'm4a', '书籍链接', '报名规则', '人才要求', '报名名额',
  '报名开始', '报名截止', '试音截止', '任务分区', '关联版权'
];

// 报名规则模板（固定）
const REGISTRATION_RULE = `【请报名学员下载文本和干音制作demo】

报名和中音流程：
1. 选择项目报名
2. 下载文本和干音并制作上传demo（命名方式：姓名+作品demo+联系方式）试音5-8分钟即可
3. 制作方选择中音学员（制作人会联络中音学员，请确保电话畅通，如电话不畅通则会更换人选，请悉知。）
4. 制作方在合作开始前、合作中都会根据后期能力、沟通顺畅与否、责任心等进行淘汰或更换人选，如不接受请勿投递试音。
5. 制作方与学员达成合作后（要求听从制作人的统一安排，按质按量完成每天的交音。）
6. 严禁商单外包！如需团队合作，每位后期都必须经过甲方认可，如出现违规，平台将严肃处理。`;

// ==================== 工具函数 ====================

function parseNumber(value) {
  if (value === null || value === undefined || value === '') return 0;
  let str = String(value).trim();
  if (str === '' || str === '无' || str === '无预付' || str === '无预付F含') return 0;
  // 处理 "0（纯分成）" 格式
  if (str.includes('（')) str = str.split('（')[0];
  if (str.includes('(')) str = str.split('(')[0];
  const num = parseFloat(str.replace(/[,，]/g, ''));
  return isNaN(num) ? 0 : num;
}

function parseWordCount(value) {
  if (!value) return 0;
  let str = String(value).trim();
  if (str === '') return 0;

  // 处理 "28万字，连载中万字" 这种格式
  if (str.includes('，')) {
    str = str.split('，')[0];  // 取第一部分
  }

  if (str.includes('万')) {
    str = str.replace(/万字?/g, '');
    const num = parseFloat(str);
    return isNaN(num) ? 0 : Math.round(num * 10000);
  }

  // 如果是纯数字（如 "98"），视为"万"
  const num = parseNumber(str);
  if (num > 0 && num < 1000) {
    // 小于1000的数字，视为"万"（98 → 980000）
    return num * 10000;
  }
  return num;
}

function parsePostCondition(value) {
  if (!value) return 0;
  const str = String(value).trim();
  return POST_CONDITION_MAP[str] || 0;
}

function parseBookTypes(value) {
  const result = {};
  BOOK_TYPE_COLUMNS.forEach(col => result[col] = 0);
  if (!value) return result;

  const str = String(value).trim();
  // 分割多个类型
  const types = str.split(/[,，、\s]+/);
  types.forEach(t => {
    t = t.trim();
    if (BOOK_TYPE_MAP[t]) {
      result[BOOK_TYPE_MAP[t]] = 1;
    }
  });
  return result;
}

function parseSalary(salaryTypeStr, hourlyRate, shareRatio, packageSalary) {
  const salaryType = String(salaryTypeStr || '').trim();
  const hourly = parseNumber(hourlyRate);
  const share = parseNumber(shareRatio);
  const pkg = parseNumber(packageSalary);

  // 打包薪资
  if (salaryType.includes('打包')) {
    // 打包可以和分成同时存在
    return {
      salaryType: 1,
      baseSalaryType: 2,  // 打包薪资
      baseSalary: pkg,
      commission: share,  // 可能有分成
      recruitQuota: 80     // 打包薪资 → 80人
    };
  }

  // 时薪或分成
  if (hourly > 0) {
    // 时薪（可能有分成）
    return {
      salaryType: 1,
      baseSalaryType: 1,  // 时薪
      baseSalary: hourly,
      commission: share,
      recruitQuota: 80    // 时薪 → 80人
    };
  } else {
    // 纯分成
    return {
      salaryType: 1,
      baseSalaryType: 1,
      baseSalary: 0,
      commission: share,
      recruitQuota: 30    // 纯分成 → 30人
    };
  }
}

function calculateRegistrationTimes(publishDateStr) {
  const parts = publishDateStr.split('-');
  const publishDate = new Date(parts[0], parts[1] - 1, parts[2]);

  // 报名开始：发布日期的第二天上午10:00
  const regStartDT = new Date(parts[0], parts[1] - 1, parts[2]);
  regStartDT.setDate(regStartDT.getDate() + 1);

  const ry = regStartDT.getFullYear(), rm = regStartDT.getMonth(), rd = regStartDT.getDate();
  const regStartDate = new Date(ry, rm, rd, 10, 0, 0);
  const regStart = dateToExcelSerialExact(ry, rm, rd) + 10 / 24;

  // 报名截止：当周周日23:59:59
  // getDay(): 0=周日，算出距周日还差几天
  const regStartWeekday = regStartDT.getDay();
  const daysToSunday = regStartWeekday === 0 ? 0 : (7 - regStartWeekday);
  const sunDT = new Date(ry, rm, rd + daysToSunday);
  const sy = sunDT.getFullYear(), sm = sunDT.getMonth(), sd = sunDT.getDate();
  const regEndDate = new Date(sy, sm, sd, 23, 59, 59);
  const regEnd = dateToExcelSerialExact(sy, sm, sd) + (23 + 59 / 60 + 59 / 3600) / 24;

  // 试音截止：报名截止的下一天（周一）12:00:00
  const monDT = new Date(sy, sm, sd + 1);
  const my = monDT.getFullYear(), mm = monDT.getMonth(), md = monDT.getDate();
  const auditionEndDate = new Date(my, mm, md, 12, 0, 0);
  const auditionEnd = dateToExcelSerialExact(my, mm, md) + 12 / 24;

  return {
    regStart,
    regEnd,
    auditionEnd,
    regStartStr: formatDate(regStartDate),
    regEndStr: formatDate(regEndDate),
    auditionEndStr: formatDate(auditionEndDate),
  };
}

function formatDate(d) {
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

// 精确计算Excel日期序列号的整数部分（只算天数）
function dateToExcelSerialExact(year, month, day) {
  // Excel基准：1900年1月1日 = 序列号1
  // 但Excel有1900闰年bug，所以1899年12月30日 = ���列号0
  const epoch = new Date(1899, 11, 30);
  const target = new Date(year, month, day);
  return Math.round((target - epoch) / (24 * 60 * 60 * 1000));
}

function parseRecruitCount(value) {
  if (!value) return 1;
  const str = String(value).trim();
  // 从 "3个后期" 或 "2个" 中提取数字
  const match = str.match(/(\d+)/);
  return match ? parseInt(match[1]) : 1;
}

// ==================== 核心转换 ====================

function readCSV(filePath) {
  // 尝试多种编码读取CSV
  const encodings = ['utf-8', 'gbk', 'gb2312', 'utf-8-sig'];
  let rows = null;

  for (const enc of encodings) {
    try {
      const buffer = fs.readFileSync(filePath);
      let text;
      if (enc === 'utf-8' || enc === 'utf-8-sig') {
        text = buffer.toString('utf-8');
        if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1); // BOM
      } else {
        text = iconv.decode(buffer, enc);
      }

      const workbook = XLSX.read(text, { type: 'string' });
      const sheetName = workbook.SheetNames[0];
      rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: '' });

      if (rows.length > 0) {
        console.log(`使用编码 ${enc} 成功读取，共 ${rows.length} 条记录`);
        return rows;
      }
    } catch (e) {
      // 继续尝试下一种编码
    }
  }

  // 最后尝试直接用xlsx库读取
  try {
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    rows = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { defval: '' });
    if (rows.length > 0) {
      console.log(`使用XLSX库成功读取，共 ${rows.length} 条记录`);
      return rows;
    }
  } catch (e) {
    // ignore
  }

  throw new Error('无法读取CSV文件，请检查文件格式和编码');
}

function convertToLMS(csvRows, publishDate) {
  const { regStart, regEnd, auditionEnd, regStartStr, regEndStr, auditionEndStr } = calculateRegistrationTimes(publishDate);
  console.log(`\n报名时间计算结果：`);
  console.log(`  报名开始: ${regStartStr}`);
  console.log(`  报名截止: ${regEndStr}`);
  console.log(`  试音截止: ${auditionEndStr}\n`);

  const outputRows = [];

  csvRows.forEach((row, idx) => {
    // 用getField获取字段值（兼容完整字段名）
    const salaryStr = getField(row, '薪资构成');
    const hourlyRate = getField(row, '时薪酬劳');
    const shareRatio = getField(row, '分成比例');
    const packageSalary = getField(row, '打包薪资');

    // 解析薪资
    const salary = parseSalary(salaryStr, hourlyRate, shareRatio, packageSalary);

    // 解析书籍类型
    const bookTypes = parseBookTypes(getField(row, '书籍类别'));

    // 解析招募数量
    const recruitCount = parseRecruitCount(getField(row, '招募数量'));

    // 构建输出行
    const outputRow = {};
    EXCEL_COLUMNS.forEach(col => outputRow[col] = '');

    outputRow['任务编号'] = '';
    outputRow['任务类型'] = 2;
    outputRow['专辑归属'] = 2;
    outputRow['就业方'] = 1;
    outputRow['薪资类型'] = salary.salaryType;
    outputRow['基础薪资类型'] = salary.baseSalaryType;
    outputRow['基础薪资'] = salary.baseSalary;
    outputRow['提成薪资'] = salary.commission;
    outputRow['书名'] = String(getField(row, '作品名称')).slice(0, 20);
    outputRow['作者'] = String(getField(row, '作品作者')).slice(0, 20);
    outputRow['后期条件'] = parsePostCondition(getField(row, '后期条件'));
    outputRow['每天集数'] = parseNumber(getField(row, '每天交音'));
    outputRow['每集分钟数'] = parseNumber(getField(row, '每集预估'));
    outputRow['要求上架时间'] = getField(row, '书籍类别');
    outputRow['字数估算'] = parseWordCount(getField(row, '作品总字数'));

    // 书籍类型
    BOOK_TYPE_COLUMNS.forEach(col => {
      outputRow[col] = bookTypes[col] || 0;
    });

    outputRow['书籍简介'] = String(getField(row, '制作要求')).slice(0, 500);
    outputRow['采样率48KHZ/44.1KHZ'] = 1;
    outputRow['深度32bit'] = 1;
    outputRow['码率192kbps/256kbps'] = 1;
    outputRow['双声道'] = 1;
    outputRow['mp3'] = 1;
    outputRow['m4a'] = 0;
    outputRow['书籍链接'] = '';
    outputRow['报名规则'] = REGISTRATION_RULE;
    outputRow['人才要求'] = 0;
    outputRow['报名名额'] = salary.recruitQuota;
    outputRow['报名开始'] = regStart;
    outputRow['报名截止'] = regEnd;
    outputRow['试音截止'] = auditionEnd;
    outputRow['任务分区'] = 3;
    outputRow['关联版权'] = '';

    outputRows.push(outputRow);
  });

  return outputRows;
}

function generateChecklist(csvRows, outputPath) {
  let text = '';
  text += '='.repeat(60) + '\n';
  text += '音频后期招募核对清单\n';
  text += `生成时间: ${formatDate(new Date())}\n`;
  text += '='.repeat(60) + '\n\n';

  csvRows.forEach((row, idx) => {
    text += `[${idx + 1}] ${getField(row, '作品名称') || '未知作品'}\n`;
    text += `  主播名: ${getField(row, '主播名') || '未知'}\n`;
    text += `  UID: ${getField(row, 'UID') || '未知'}\n`;
    text += `  手机号: ${getField(row, '手机号') || '未知'}\n`;
    text += `  作者: ${getField(row, '作品作者') || '未知'}\n`;
    text += `  薪资构成: ${getField(row, '薪资构成') || '未知'}\n`;
    text += `  时薪/分成: ${getField(row, '时薪酬劳') || 0} / ${getField(row, '分成比例') || 0}%\n`;
    text += `  打包薪资: ${getField(row, '打包薪资') || '无'}\n`;
    text += `  后期要求: ${getField(row, '后期条件') || '未知'}\n`;
    text += `  需求数量: ${getField(row, '招募数量') || '未知'}\n`;
    text += `  作品总字: ${getField(row, '作品总字数') || '未知'}\n`;
    text += `  每天交音: ${getField(row, '每天交音') || '未知'}\n`;
    text += `  状态: [ ] 待核对\n`;
    text += '-'.repeat(40) + '\n\n';
  });

  fs.writeFileSync(outputPath, text, 'utf-8');
  console.log(`核对清单已生成: ${outputPath}`);
}

// 模板说明行（第二行）
const TEMPLATE_INSTRUCTION_ROW = [
  '用户输入本次导入数量后，模版自动生成编号，用户不可自行修改',
  '2音频剪辑\n',
  '1 版权方 \n2 个人\n3 需求招募方',
  '1 喜马拉雅-版权书制作平台\n2 喜马拉雅-奇迹文学事业部\n3 喜马拉雅-泛播客事业部\n4 喜马拉雅-价值出版事业部\n5 外部合作方\n6 有声书AIGC运营组',
  '1 固定，必须填写保底薪资&提成薪资\n2 浮动，保底薪资和提成薪资二选一',
  '1-保底薪资，此时基础薪资展示的是元/小时\n2-打包薪资，此时基础薪资展示的是元\n',
  '格式要求：\n薪资类型为固定：若数值为0，为"无基础薪资"\n薪资类型浮动：如20,30（注意","是半角的）',
  '1 固定：%，若数值为0，为"无提成任务"，不出现在任务列表\n2 浮动：%，如:50,70（注意","是半角的）',
  '文字信息录入，限20个字符，超过后出现"…"',
  '文字信息录入，限20个字符，超过后出现"…"',
  '0=不限后期；1=干音；2=简配；3=中配；4=精配;5=超简配;6=简中配;7=中精配 ',
  '数字录入，限正整数，不超过100',
  '数字录入，限正整数，不超过500',
  '时间录入，格式样例：2023-08-20',
  '数字录入，整数',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '文本输入，限500字；使用**高亮展示星号内文本',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '1为选中，0为未选中\n',
  '限输入网址格式，限300字',
  '文本输入，限1000字；使用**高亮展示星号内文本',
  '输入整数数字，0-5之间（0为等级不限）',
  '可输入整数数字（1-1000）',
  'YYYY-MM-DD HH:MM:SS格式输入时间，输入时间不得早于录入当天的24点',
  'YYYY-MM-DD HH:MM:SS格式输入时间，输入时间不得早于录入当天的24点',
  'YYYY-MM-DD HH:MM:SS格式输入时间，输入时间不得早于"报名截止时间"',
  '任务分区（输入数字）：2=入门区，3=进阶区',
  '这里输入版权库书名，根据版权库书名精确匹配',
];

function writeExcel(outputRows, outputPath) {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(outputRows, { header: EXCEL_COLUMNS });

  // 插入模板说明行（作为第二行，row index=1）
  // 先把所有数据行下移一行
  const range = XLSX.utils.decode_range(ws['!ref']);
  // 从最后一行开始，把每行数据下移
  for (let r = range.e.r; r >= 1; r--) {
    for (let c = range.s.c; c <= range.e.c; c++) {
      const oldAddr = XLSX.utils.encode_cell({ r, c });
      const newAddr = XLSX.utils.encode_cell({ r: r + 1, c });
      if (ws[oldAddr]) {
        ws[newAddr] = ws[oldAddr];
        delete ws[oldAddr];
      }
    }
  }

  // 写入模板说明行到row 1
  TEMPLATE_INSTRUCTION_ROW.forEach((val, c) => {
    const addr = XLSX.utils.encode_cell({ r: 1, c });
    ws[addr] = { t: 's', v: val };
  });

  // 更新范围
  range.e.r += 1;
  ws['!ref'] = XLSX.utils.encode_range(range);

  // 给时间列添加日期格式
  const dateFmt = 'yyyy-mm-dd';
  const timeCols = ['报名开始', '报名截止', '试音截止'];
  timeCols.forEach(colName => {
    const colIdx = EXCEL_COLUMNS.indexOf(colName);
    if (colIdx === -1) return;
    for (let r = 2; r <= range.e.r; r++) {
      const addr = XLSX.utils.encode_cell({ r, c: colIdx });
      if (ws[addr] && ws[addr].t === 'n') {
        ws[addr].z = dateFmt;
      }
    }
  });

  // 设置列宽
  ws['!cols'] = EXCEL_COLUMNS.map(col => {
    if (col === '书籍简介' || col === '报名规则') return { wch: 30 };
    if (col === '书名' || col === '作者') return { wch: 20 };
    if (col === '任务编号') return { wch: 18 };
    return { wch: 14 };
  });

  XLSX.utils.book_append_sheet(wb, ws, '音频剪辑任务导入');
  XLSX.writeFile(wb, outputPath);
  console.log(`Excel已生成: ${outputPath}`);
}

// ==================== 主程序 ====================

function askQuestion(rl, question) {
  return new Promise(resolve => rl.question(question, resolve));
}

async function main() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  console.log('\n' + '='.repeat(50));
  console.log('  音频后期招募自动化工具 v1.0');
  console.log('='.repeat(50) + '\n');

  // 获取输入文件
  let inputFile;
  if (process.argv.length > 2) {
    inputFile = process.argv[2];
  } else {
    inputFile = await askQuestion(rl, '请输入腾讯文档导出的CSV文件路径\n（可以直接把文件拖拽到这个窗口）:\n> ');
    inputFile = inputFile.trim().replace(/^"|"$/g, '');
  }

  if (!fs.existsSync(inputFile)) {
    console.log(`错误: 文件不存在 - ${inputFile}`);
    rl.close();
    return;
  }

  // 获取发布日期
  const today = formatDate(new Date()).split(' ')[0];
  let publishDate = await askQuestion(rl, `\n请输入发布日期（格式：YYYY-MM-DD）\n（直接回车使用今天 ${today}）:\n> `);
  publishDate = publishDate.trim() || today;

  rl.close();

  try {
    console.log('\n' + '-'.repeat(50));

    // 1. 读取CSV
    console.log(`正在读取: ${inputFile}`);
    const csvRows = readCSV(inputFile);

    if (csvRows.length === 0) {
      console.log('错误: CSV文件为空');
      return;
    }

    // 显示读取到的列名
    console.log(`检测到字段: ${Object.keys(csvRows[0]).join(', ')}\n`);

    // 2. 转换为LMS格式
    const outputRows = convertToLMS(csvRows, publishDate);
    console.log(`转换完成！共 ${outputRows.length} 条记录\n`);

    // 3. 生成输出文件
    const inputDir = path.dirname(inputFile);
    const baseName = path.basename(inputFile, path.extname(inputFile));

    const outputExcel = path.join(inputDir, `${baseName}_LMS导入.xlsx`);
    const outputChecklist = path.join(inputDir, `${baseName}_核对清单.txt`);

    writeExcel(outputRows, outputExcel);
    generateChecklist(csvRows, outputChecklist);

    // 4. 显示预览
    const times = calculateRegistrationTimes(publishDate);
    console.log('\n' + '-'.repeat(50));
    console.log('数据预览（前3条）:');
    outputRows.slice(0, 3).forEach((row, i) => {
      console.log(`\n  [${i + 1}] ${row['书名']}`);
      console.log(`      作者: ${row['作者']}`);
      console.log(`      薪资: ${row['基础薪资']}${row['基础薪资类型'] === 1 ? '元/时' : '元'} + ${row['提成薪资']}%提成`);
      console.log(`      后期: ${row['后期条件']} | 每天${row['每天集数']}集 | ${row['每集分钟数']}分钟/集`);
      console.log(`      名额: ${row['报名名额']} | 报名: ${times.regStartStr}`);
    });

    console.log('\n' + '='.repeat(50));
    console.log('全部完成！');
    console.log(`导出Excel: ${outputExcel}`);
    console.log(`核对清单: ${outputChecklist}`);
    console.log('='.repeat(50) + '\n');

  } catch (e) {
    console.log(`\n错误: ${e.message}`);
    console.log(e.stack);
  }
}

main();
