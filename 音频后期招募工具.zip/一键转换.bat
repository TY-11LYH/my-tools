@echo off
chcp 65001 >nul
title 音频后期招募自动化工具
echo.
echo ================================================
echo   音频后期招募自动化工具 v1.0
echo   双击运行此文件即可使用
echo ================================================
echo.
node "%~dp0tool.js" %1
echo.
pause
