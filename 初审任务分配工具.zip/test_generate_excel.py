#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
测试生成终审批量开通表格
"""

import sys
import os
import csv
from datetime import datetime, timedelta

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')

try:
    from openpyxl import load_workbook
except ImportError:
    print("需要安装 openpyxl: pip install openpyxl")
    sys.exit(1)


def read_reviewers_from_csv(csv_dir, csv_dates):
    """从音频导入任务的CSV文件中提取主播名和uid"""
    reviewers = set()

    for date_folder in csv_dates:
        folder_path = os.path.join(csv_dir, date_folder)
        if not os.path.exists(folder_path):
            print(f"  警告: 文件夹不存在 - {folder_path}")
            continue

        csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
        if not csv_files:
            print(f"  警告: 文件夹里没有CSV文件 - {folder_path}")
            continue

        csv_file = os.path.join(folder_path, csv_files[0])
        print(f"  读取文件: {csv_file}")

        for encoding in ['utf-8', 'gbk', 'gb18030', 'utf-8-sig']:
            try:
                with open(csv_file, 'r', encoding=encoding) as f:
                    reader = csv.reader(f)
                    next(reader)
                    count = 0
                    for row in reader:
                        if len(row) > 3:
                            name = row[2].strip()
                            uid = row[3].strip()
                            if name and uid:
                                reviewers.add((name, uid))
                                count += 1
                print(f"    成功读取 (编码: {encoding})，提取 {count} 条记录")
                break
            except UnicodeDecodeError:
                continue
            except Exception as e:
                print(f"    警告: 读取失败 - {e}")
                break

    return sorted(list(reviewers))


def get_next_tuesday():
    """计算下周二的日期"""
    today = datetime.now()
    days_until_tuesday = (1 - today.weekday() + 7) % 7
    if days_until_tuesday == 0:
        days_until_tuesday = 7
    next_tuesday = today + timedelta(days=days_until_tuesday)
    return next_tuesday


def generate_final_review_table(reviewers, next_tuesday, template_path, output_dir):
    """生成终审批量开通表格"""
    print(f"\n读取模板: {template_path}")
    wb = load_workbook(template_path)
    ws = wb.active

    print(f"清空模板数据...")
    for row in range(2, ws.max_row + 1):
        for col in range(1, ws.max_column + 1):
            ws.cell(row=row, column=col).value = None

    account_deadline = datetime(2026, 12, 31)
    role = "2交付版权方"

    print(f"填写数据...")
    for i, (name, uid) in enumerate(reviewers, 2):
        ws.cell(row=i, column=1).value = uid
        ws.cell(row=i, column=2).value = name
        ws.cell(row=i, column=4).value = account_deadline
        ws.cell(row=i, column=5).value = role
        ws.cell(row=i, column=6).value = next_tuesday

    date_str = next_tuesday.strftime('%m.%d').lstrip('0')
    output_file = os.path.join(output_dir, f"{date_str}终审批量开通.xlsx")
    print(f"保存文件: {output_file}")
    wb.save(output_file)

    return output_file


def main():
    print("===== 生成终审批量开通表格测试 =====\n")

    csv_dir = r'C:\Users\xbjt\Desktop\音频导入任务'
    csv_dates = ['4.29上传', '4.30上传']
    template_path = r'C:\Users\xbjt\Desktop\终审批量开通\终审批量开通模板（周二上班发给大美）.xlsx'
    output_dir = r'C:\Users\xbjt\Desktop\终审批量开通'

    # 检查模板文件
    if not os.path.exists(template_path):
        print(f"错误: 模板文件不存在 - {template_path}")
        sys.exit(1)

    print(f"CSV目录: {csv_dir}")
    print(f"日期文件夹: {', '.join(csv_dates)}")
    print(f"模板文件: {template_path}")
    print(f"输出目录: {output_dir}\n")

    # 提取主播信息
    print("===== 步骤1: 读取CSV文件 =====")
    reviewers = read_reviewers_from_csv(csv_dir, csv_dates)

    if not reviewers:
        print("错误: 没有提取到主播信息")
        sys.exit(1)

    print(f"\n共提取 {len(reviewers)} 位主播（已去重）")

    # 计算下周二
    next_tuesday = get_next_tuesday()
    print(f"\n===== 步骤2: 生成表格 =====")
    print(f"截止时间: {next_tuesday.strftime('%Y-%m-%d')} (下周二)")

    # 生成表格
    output_file = generate_final_review_table(reviewers, next_tuesday, template_path, output_dir)

    print(f"\n===== 完成 =====")
    print(f"✅ 终审批量开通表格已生成: {output_file}")
    print(f"\n表格内容预览：")
    print(f"  - 共 {len(reviewers)} 位主播")
    print(f"  - 账号有效期: 2026-12-31")
    print(f"  - 角色: 2交付版权方")
    print(f"  - 角色有效期: {next_tuesday.strftime('%Y-%m-%d')}")


if __name__ == '__main__':
    main()
